Run BookStoreApplication.java from com.book.store package.

import bookStoreCollection.postman_collection.json from src/main/resource to postman tool.

Run book.sql schema on h2 database.

Then run localhost:8081/bookstore/v1/read from postman

