package com.book.store.xml.model;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;

public class Author {

    private List<String> author;
    
    @XmlElement(name = "author")
    public List<String> getAuthor() {
        return author;
    }

    public void setAuthor(List<String> author) {
        this.author = author;
    }



    @Override
    public String toString() {
        return "Author [author=" + author + "]";
    }
}
