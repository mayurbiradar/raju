package com.book.store.json.model;

public class AddBookStore {

	private long id;
	private String title;
	private String category;
	private Long year;
	private double price;
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}
	private String author;

	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Long getYear() {
		return year;
	}
	public void setYear(Long year) {
		this.year = year;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}

}
