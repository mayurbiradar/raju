package com.book.store.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.book.store.exceptions.GeneralException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectMapperUtil {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ObjectMapperUtil.class);

    private ObjectMapperUtil() {
        throw new AssertionError("No Object Creation");
    }

    public static String returnJsonFromObject(Object object) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException ex) {
            LOGGER.error("Json processing exception: {}", ex);
            throw new GeneralException("exception occured while marshalling the object");
        } 
    }

}
