package com.book.store.json.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName(value = "bookStore")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class BookStore {
    
    @JsonProperty("books")
    private List<BookDto> books;
    
    public List<BookDto> getBooks() {
        return books;
    }

    public void setBooks(List<BookDto> books) {
        this.books = books;
    }

    @Override
    public String toString() {
        return "BookStore [books=" + books + "]";
    }
}
