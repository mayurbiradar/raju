package com.book.store.xml.model;

import javax.xml.bind.annotation.XmlAttribute;

public class Book {

    private String title;
    
    private String category;
    
    private String lang;
    private Long year;
    private double price;
    private Author authors;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @XmlAttribute(name="category")
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @XmlAttribute(name="lang")
    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public Long getYear() {
        return year;
    }

    public void setYear(Long year) {
        this.year = year;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    public Author getAuthors() {
        return authors;
    }

    public void setAuthors(Author authors) {
        this.authors = authors;
    }

    @Override
    public String toString() {
        return "Book [title=" + title + ", category=" + category + ", language=" + lang
                + ", year=" + year + ", price=" + price + ", authors=" + authors + "]";
    }
    
    
}
