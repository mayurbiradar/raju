package com.book.store.json.model;

import java.util.List;

public class AuthorDto {

    private List<String> author;

    public List<String> getAuthor() {
        return author;
    }

    public void setAuthor(List<String> author) {
        this.author = author;
    }

}
