package com.book.store.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.book.store.entity.BookEntity;
import com.book.store.entity.CategoryEntity;
import com.book.store.repository.BookRepository;
import com.book.store.repository.CategoryRepository;

@Service
public class DefaultBookStoreService implements BookStoreService {

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Override
	public String createBookStore(List<BookEntity> bookEntities) {
		bookEntities.forEach(bookEntity -> {
			CategoryEntity categoryEntity =
					categoryRepository.findByType(bookEntity.getCategory().getType());
			bookEntity.setCategory(categoryEntity);
			bookEntity.getAuthors().forEach(book -> {
				bookEntity.getAuthors().forEach(author -> {
					author.setBook(bookEntity);
				});
			});
			bookRepository.save(bookEntity);
		});
		return "success";
	}

	@Override
	public String updateBookStore(List<BookEntity> bookEntities) {
		bookEntities.forEach(bookEntity -> {
			BookEntity b=bookRepository.findById(bookEntity.getId()).get();	
			b.setPrice(bookEntity.getPrice());
			b.setTitle(bookEntity.getTitle());
			b.setYear(bookEntity.getYear());
			b.setAuthors(bookEntity.getAuthors());
			CategoryEntity categoryEntity =
					categoryRepository.findByType(bookEntity.getCategory().getType());
			b.setCategory(categoryEntity);
			BookEntity bookResult = bookRepository.saveAndFlush(b);
			bookResult.getAuthors().forEach(book -> {
				b.getAuthors().forEach(author -> {
					author.setBook(bookResult);
				});
			});
			bookRepository.save(b);
		});
		return "success";
	}

	@Override
	public String deleteBookStore(Long bookId) {
		bookRepository.deleteById(bookId);
		return "success";
	}

	@Override
	public List<BookEntity> fetchAllBookStoreData() {
		return bookRepository.findAll();
	}

	@Override
	public BookEntity getBookById(long bookId) {
		return bookRepository.findById(bookId).get();
	}

}
