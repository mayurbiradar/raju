package com.book.store.exceptions;

public class GeneralException extends RuntimeException {

    private static final long serialVersionUID = 1084904499909012955L;

    private final String message;

    public GeneralException(String message) {
        super(message);
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

}
