package com.book.store.converters;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Component;
import com.book.store.Converter;
import com.book.store.entity.AuthorsEntity;
import com.book.store.entity.BookEntity;
import com.book.store.entity.CategoryEntity;
import com.book.store.xml.model.Book;

@Component
public class BookConverter implements Converter<List<Book>, List<BookEntity>> {

    @Override
    public List<BookEntity> convert(List<Book> inputList) {
        List<BookEntity> bookEntities = new ArrayList<>();
        inputList.forEach(input -> {
            BookEntity bookEntity = new BookEntity();
            bookEntity.setLanguage(input.getLang());
            bookEntity.setTitle(input.getTitle());
            bookEntity.setPrice(input.getPrice());
            bookEntity.setYear(input.getYear());
            Set<AuthorsEntity> authors = new HashSet<>();
            input.getAuthors().getAuthor().forEach(author -> {
                AuthorsEntity authorEntity = new AuthorsEntity();
                authorEntity.setName(author);
                authors.add(authorEntity);
            });
            bookEntity.setAuthors(authors);
            CategoryEntity categoryEntity = new CategoryEntity();
            categoryEntity.setType(input.getCategory());
            bookEntity.setCategory(categoryEntity);
            bookEntities.add(bookEntity);
        });
        return bookEntities;
    }
}
