package com.book.store.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.store.converters.AddBookStoreConverter;
import com.book.store.converters.BookConverter;
import com.book.store.converters.BookEntityConverter;
import com.book.store.entity.BookEntity;
import com.book.store.json.model.AddBookStore;
import com.book.store.json.model.BookResponse;
import com.book.store.json.model.BookStore;
import com.book.store.service.BookStoreService;
import com.book.store.util.ObjectMapperUtil;

@RestController 
@RequestMapping(value = "bookstore/v1")
public class BookStoreController {

    private static final Logger LOG = LoggerFactory.getLogger(BookStoreController.class);

    @Autowired
    private BookConverter bookConverter;

    @Autowired
    private BookStoreService bookStoreService;

    @Autowired
    private BookEntityConverter bookEntityConverter;

    @Autowired
    private AddBookStoreConverter addBookStoreConverter;

    @GetMapping(path = "/read", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookResponse> readBokStoreDeatils() {
        BookResponse response = null;
        try {
            File file = new File(getClass().getClassLoader().getResource("bookstore.xml").getFile());
            JAXBContext jaxbContext =
                    JAXBContext.newInstance(com.book.store.xml.model.BookStore.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            com.book.store.xml.model.BookStore bookStore =
                    (com.book.store.xml.model.BookStore) jaxbUnmarshaller.unmarshal(file);
            LOG.info("Incoming BookStore xml {}", bookStore);
            String reply =
                    bookStoreService.createBookStore(bookConverter.convert(bookStore.getBook()));
            response = buildResponse(reply);
        } catch (JAXBException ex) {
            LOG.error("exception occured while reading xml file", ex);
        }
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping(path = "/book-all", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookStore> readAllBookStoreDeatils() {
        List<BookEntity> bookEntities = bookStoreService.fetchAllBookStoreData();
        BookStore bookStore = bookEntityConverter.convert(bookEntities);
        return new ResponseEntity<>(bookStore, HttpStatus.CREATED);
    }

    @GetMapping(path = "/book/{bookId}", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookStore> readBookStoreByBooKId(@PathVariable long bookId) {
        BookEntity bookEntity = bookStoreService.getBookById(bookId);
        List<BookEntity> bookEntities = new ArrayList<>();
        bookEntities.add(bookEntity);
        BookStore bookStore = bookEntityConverter.convert(bookEntities);
        return new ResponseEntity<>(bookStore, HttpStatus.CREATED);
    }

    @PostMapping(path = "/create", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookResponse> createBookStoreDeatils(
            @RequestBody @Valid AddBookStore bookStore) {
        LOG.info("Incoming BookStore json {}", bookStore);
        String reply = bookStoreService.createBookStore(addBookStoreConverter.convert(bookStore));
        BookResponse response = buildResponse(reply);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/update", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookResponse> updateBookStoreDeatils(
            @RequestBody AddBookStore bookStore) {
        LOG.info("Incoming BookStore json {}", ObjectMapperUtil.returnJsonFromObject(bookStore));
        String reply = bookStoreService.updateBookStore(addBookStoreConverter.convert(bookStore));
        BookResponse response = buildResponse(reply);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @DeleteMapping(path = "/delete/{bookId}", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookResponse> deleteBookStoreDeatils(@PathVariable long bookId) {
        LOG.info("Incoming bookId {}", bookId);
        String reply = bookStoreService.deleteBookStore(bookId);
        BookResponse response = buildResponse(reply);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    private BookResponse buildResponse(String reply) {
        BookResponse response = new BookResponse();
        response.setStatus(reply);
        response.setMessage("opteration is successful");
        return response;
    }
}
