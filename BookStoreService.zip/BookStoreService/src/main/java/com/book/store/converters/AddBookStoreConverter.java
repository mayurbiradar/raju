package com.book.store.converters;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.book.store.Converter;
import com.book.store.entity.AuthorsEntity;
import com.book.store.entity.BookEntity;
import com.book.store.entity.CategoryEntity;
import com.book.store.json.model.AddBookStore;

@Component
public class AddBookStoreConverter implements Converter<AddBookStore, List<BookEntity>> {

    @Override
    public List<BookEntity> convert(AddBookStore input) {
    	List<BookEntity> bookEntities=new ArrayList<BookEntity>();
        BookEntity bookEntity = new BookEntity();
        bookEntity.setId(input.getId());
        CategoryEntity categoryEntity = new CategoryEntity();
        categoryEntity.setType(input.getCategory());  
        bookEntity.setCategory(categoryEntity);
        bookEntity.setTitle(input.getTitle());
        bookEntity.setPrice(input.getPrice());
        bookEntity.setYear(input.getYear());
        Set<AuthorsEntity> authors = new HashSet<>();
        AuthorsEntity authorEntity = new AuthorsEntity();
        authorEntity.setName(input.getAuthor());;
        authors.add(authorEntity);
        bookEntity.setAuthors(authors);
        bookEntities.add(bookEntity);
        return bookEntities;
    }
}
