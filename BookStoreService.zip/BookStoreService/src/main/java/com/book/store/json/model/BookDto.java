package com.book.store.json.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BookDto {

    private long id;
    private String title;

    private String category;

    private String lang;
    private Long year;
    private double price;
    @JsonProperty("authors")
    private List<String> author;
    
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getLang() {
        return lang;
    }
    public void setLang(String lang) {
        this.lang = lang;
    }
    public Long getYear() {
        return year;
    }
    public void setYear(Long year) {
        this.year = year;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    
    public List<String> getAuthor() {
        return author;
    }

    public void setAuthor(List<String> author) {
        this.author = author;
    }
    @Override
    public String toString() {
        return "BookDto [title=" + title + ", category=" + category + ", lang=" + lang + ", year="
                + year + ", price=" + price + ", authors=" + author + "]";
    }

}
