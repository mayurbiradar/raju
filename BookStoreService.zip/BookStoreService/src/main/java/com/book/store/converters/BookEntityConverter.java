package com.book.store.converters;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.book.store.Converter;
import com.book.store.entity.AuthorsEntity;
import com.book.store.entity.BookEntity;
import com.book.store.json.model.BookDto;
import com.book.store.json.model.BookStore;

@Component
public class BookEntityConverter implements Converter<List<BookEntity>, BookStore> {

    @Override
    public BookStore convert(List<BookEntity> inputList) {
        BookStore bookStore = new BookStore();
        List<BookDto> books = new ArrayList<>();
        inputList.stream().forEach(input -> {
            BookDto bookDto = new BookDto();
            bookDto.setId(input.getId());
            bookDto.setCategory(input.getCategory().getType());
            bookDto.setTitle(input.getTitle());
            bookDto.setPrice(input.getPrice());
            bookDto.setYear(input.getYear());
            List<String> authors = new ArrayList<>();
            for (AuthorsEntity author : input.getAuthors()) {
                authors.add(author.getName());
                bookDto.setAuthor(authors);
            }
            books.add(bookDto);
        });
        bookStore.setBooks(books);
        return bookStore;
    }

}
