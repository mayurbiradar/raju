package com.book.store.converters;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Component;
import com.book.store.Converter;
import com.book.store.entity.AuthorsEntity;
import com.book.store.entity.BookEntity;
import com.book.store.entity.CategoryEntity;
import com.book.store.json.model.BookStore;

@Component
public class BookStoreDtoConverter implements Converter<BookStore, List<BookEntity>> {

    @Override
    public List<BookEntity> convert(BookStore bookStoreDto) {
        List<BookEntity> bookEntities = new ArrayList<>();
        bookStoreDto.getBooks().forEach(input -> {
            BookEntity bookEntity = new BookEntity();
            bookEntity.setLanguage(input.getLang());
            bookEntity.setTitle(input.getTitle());
            bookEntity.setPrice(input.getPrice());
            bookEntity.setYear(input.getYear());
            Set<AuthorsEntity> authors = new HashSet<>();
            input.getAuthor().forEach(author -> {
                AuthorsEntity authorEntity = new AuthorsEntity();
                authorEntity.setName(author);
                authors.add(authorEntity);
            });
            bookEntity.setAuthors(authors);
            CategoryEntity categoryEntity = new CategoryEntity();
            categoryEntity.setType(input.getCategory());
            bookEntity.setCategory(categoryEntity);
            bookEntities.add(bookEntity);
        });
        return bookEntities;
    }
}
