package com.book.store.service;

import java.util.List;
import com.book.store.entity.BookEntity;

public interface BookStoreService {

    String createBookStore(List<BookEntity> bookEntity);
    
    String deleteBookStore(Long bookId);
    
    List<BookEntity> fetchAllBookStoreData();
    
    BookEntity getBookById(long bookId);
    
    String updateBookStore(List<BookEntity> bookEntity);


}
