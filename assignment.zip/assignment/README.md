# How to run application

1.Unzip both the folders
2. run the BookStoreService springboot application
3. open http://localhost:8081/h2-console and the click on 'connect'
4. Copy sql queries from book.sql and run in h2 database
5. Goto angular-book-store path and run "npm install"
6. Then again on the same path i.e /angular-book-store  run "ng serve"

Web Application is running on http://localhost:4200/list-book


#About application
1. springboot application is running on port 8081
2. angular application is running on 4200
3. we can deploy springboot application by creating build (as it's a maven application)
4. Currently springboot application is using embedded tomcat server
5. angular application is using embedded server
6. Implemented Read XML,Add new book,Delete book,Update book functionalities

#Technologies Used
1. Springboot
2. Maven
3. JPA (Hibernate)
4. H2 database
5. Angular
