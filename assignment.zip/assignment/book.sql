CREATE TABLE PUBLIC.`category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
); 

CREATE TABLE PUBLIC.`book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `price` DECIMAL DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
); 

CREATE TABLE PUBLIC.`author` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL ,
  PRIMARY KEY (`id`)
); 


ALTER TABLE PUBLIC.book ADD FOREIGN KEY (category_id) REFERENCES PUBLIC.category(id);

ALTER TABLE PUBLIC.author ADD FOREIGN KEY (book_id) REFERENCES PUBLIC.book(id);

INSERT INTO PUBLIC.category values(1, 'cooking');
INSERT INTO PUBLIC.category values(2, 'children');
INSERT INTO PUBLIC.category values(3, 'web');