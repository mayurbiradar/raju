package com.test.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.test.dto.Student;
import com.test.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	StudentService studentService;
	

	
	@GetMapping(value="/getAllStudents")
	public List<Student> getAllStudents()
	{
		return studentService.getAllStudents();
	}
	
	
	// Create
	@PostMapping(value="/addStudent")
	public List<Student> addStudent(@RequestBody Student st)
	{
		return studentService.addStudent(st);
	}

	// Read
	@GetMapping(value="/getStudent/{id}")
	public Student getStudent(@PathVariable int id)
	{
		return studentService.getStudent(id);
	}
	
	//Update
	
	@PutMapping(value="/updateStudent")
	public List<Student> updateStudent(@RequestBody Student st)
	{
		return studentService.updateStudent(st);
	}

	
	//Delete
	@DeleteMapping(value="/deleteStudent/{id}")
	public List<Student> deleteStudent(@PathVariable int id)
	{
		return studentService.deleteStudent(id);
	}
	
}
