package com.test.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.test.dto.Student;
import com.test.repo.StudentRepo;

@Repository
public class StudentDaoImpl implements StudentDao {


	@Autowired
	StudentRepo studentRepo;
	

		@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentRepo.findAll();
	}

	@Override
	public List<Student> addStudent(Student st) {
		
		studentRepo.save(st);
		return studentRepo.findAll();
	}

	@Override
	public Student getStudent(int id) {
		// TODO Auto-generated method stub
		return studentRepo.getOne(id);
	}

	@Override
	public List<Student> updateStudent(Student st) {
		// TODO Auto-generated method stub
		studentRepo.save(st);
		return studentRepo.findAll();
	}

	@Override
	public List<Student> deleteStudent(int id) {
		// TODO Auto-generated method stub
		studentRepo.deleteById(id);
		return studentRepo.findAll();
	}

}
