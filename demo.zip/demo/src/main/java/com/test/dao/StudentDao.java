package com.test.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.test.dto.Student;

@Repository
public interface StudentDao {

	public List<Student> getAllStudents();
	public List<Student> addStudent(Student st);
	public Student getStudent(int id);
	public List<Student> updateStudent(Student st);
	public List<Student> deleteStudent(int id);
}
