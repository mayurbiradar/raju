package com.test.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.test.dto.Student;

@Service
public interface StudentService {
	
	public List<Student> getAllStudents();
	public List<Student> addStudent(Student st);
	public Student getStudent(int id);
	public List<Student> updateStudent(Student st);
	public List<Student> deleteStudent(int id);
	
	
}
