export class Response {
  result: any;
}
