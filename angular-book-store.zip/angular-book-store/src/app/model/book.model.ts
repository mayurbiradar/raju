export class Book {
  id: number;
}
